document.addEventListener("DOMContentLoaded", () => {
  const handSuitcase = document.getElementById("handSuitcase");
  const flyingSuitcase = document.getElementById("flyingSuitcase");
  const loginCard = document.getElementById("loginCard");
  const gameModel = document.getElementById("gameModel");
  
  // 1. कैरेक्टर के दौड़ने के दौरान 1.2 सेकंड पर हाथ से सूटकेस गायब होगा और हवा में उड़ेगा
  setTimeout(() => {
    if (handSuitcase) handSuitcase.style.display = "none";
    if (flyingSuitcase) flyingSuitcase.classList.add("throw");
  }, 1200);
  
  // 2. ठीक 2.0 सेकंड पर सूटकेस ज़मीन पर गिरेगा और खुलेगा
  setTimeout(() => {
    if (flyingSuitcase) flyingSuitcase.classList.add("open");
    
    // मॉडल धुंधला (Fade) होगा ताकि फोकस लॉगिन स्क्रीन पर रहे
    if (gameModel) {
      gameModel.style.transition = "opacity 0.6s ease";
      gameModel.style.opacity = "0.25";
    }
  }, 2000);
  
  // 3. सूटकेस खुलते ही तुरंत लॉगिन इंटरफ़ेस ऊपर की ओर स्मूथली पॉप-अप होगा
  setTimeout(() => {
    if (loginCard) loginCard.classList.add("appear");
  }, 2300);
});

// लॉगिन और साइनअप स्विच फंक्शनलिटी
let currentMode = "login";

function toggleForm() {
  if (currentMode === "login") {
    switchTab("signup");
  } else {
    switchTab("login");
  }
}

function switchTab(mode) {
  const toggleBar = document.getElementById("toggleBar");
  const tabLogin = document.getElementById("tab-login");
  const tabSignup = document.getElementById("tab-signup");
  const confirmField = document.getElementById("confirmField");
  const submitBtn = document.getElementById("submitBtn");
  
  currentMode = mode;
  
  if (mode === "signup") {
    if (toggleBar) toggleBar.classList.add("signup-on");
    if (tabSignup) tabSignup.classList.add("active");
    if (tabLogin) tabLogin.classList.remove("active");
    if (confirmField) confirmField.classList.add("show");
    if (submitBtn) {
      submitBtn.innerText = "CREATE ACCOUNT";
      submitBtn.style.background = "linear-gradient(90deg, #5a00ff, #00f0ff)";
    }
  } else {
    if (toggleBar) toggleBar.classList.remove("signup-on");
    if (tabLogin) tabLogin.classList.add("active");
    if (tabSignup) tabSignup.classList.remove("active");
    if (confirmField) confirmField.classList.remove("show");
    if (submitBtn) {
      submitBtn.innerText = "LAUNCH GAME";
      submitBtn.style.background = "linear-gradient(90deg, #ffaa00, #ff5500)";
    }
  }
}
// 2. ठीक 2.0 सेकंड पर सूटकेस ज़मीन पर गिरेगा और खुलेगा
setTimeout(() => {
  if (flyingSuitcase) flyingSuitcase.classList.add("open");
  
  // आलोक कैरेक्टर स्क्रीन पर शानदार तरीके से शो होता रहेगा, बस थोड़ा सा पीछे सेटल होगा
  if (gameModel) {
    gameModel.style.transition = "all 0.6s ease";
    gameModel.style.opacity = "0.85"; /* कैरेक्टर अब गायब नहीं होगा, एकदम साफ़ दिखेगा */
    gameModel.style.transform = "translate3d(-20px, 0, 0) scale(0.95)"; /* हल्का सा पीछे हटेगा */
  }
}, 2000);