function getLocation() {

    const result = document.getElementById("result");

    // Check whether the browser supports GPS
    if (!navigator.geolocation) {
        result.innerHTML = "<p>❌ Location is not supported by this browser.</p>";
        return;
    }

    result.innerHTML = "<p>📡 Getting your location...</p>";

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            const accuracy = position.coords.accuracy;

            result.innerHTML = `
                <p>✅ Location found!</p>

                <p>
                    <b>Latitude:</b><br>
                    ${latitude}
                </p>

                <p>
                    <b>Longitude:</b><br>
                    ${longitude}
                </p>

                <p>
                    <b>Accuracy:</b>
                    approximately ${Math.round(accuracy)} metres
                </p>

                <a 
                    href="https://www.google.com/maps?q=${latitude},${longitude}"
                    target="_blank">
                    🗺️ Open in Google Maps
                </a>
            `;
        },

        function(error) {

            result.innerHTML = `
                <p>❌ Could not get your location.</p>
                <p>Please allow location permission.</p>
            `;
        }

    );
}